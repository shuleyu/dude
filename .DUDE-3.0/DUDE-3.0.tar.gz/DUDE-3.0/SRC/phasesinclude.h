if ( refphase == "P" ) then
      t_header= "T0"
else if ( refphase == "Pdiff" ) then
      t_header= "T0"
else if ( refphase == "S" ) then
      t_header= "T2"
else if ( refphase == "Sdiff" ) then
      t_header= "T2"
else if ( refphase == "pP" ) then
      t_header= "T1"
else if ( refphase == "sS" ) then
      t_header= "T3"
else if ( refphase == "PP" ) then
      t_header= "T4"
else if ( refphase == "SS" ) then
      t_header= "T5"
else if ( refphase == "SKKS" ) then
      t_header= "T6"
else if ( refphase == "PKP" ) then
      t_header= "T7"
else if ( refphase == "SKS" ) then
      t_header= "T8"
else if ( refphase == "ScS" ) then
      t_header= "T9"
else
      t_header= "T1"
end if
